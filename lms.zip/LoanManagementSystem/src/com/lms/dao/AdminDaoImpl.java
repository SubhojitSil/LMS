package com.lms.dao;

import javax.persistence.EntityManager;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class AdminDaoImpl implements IAdminDao {
	private EntityManager entityManager;
	public AdminDaoImpl() {
		entityManager=JPAUtil.getEntityManager();
	}
	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException {
	boolean isInserted=false;
	try {
		entityManager.getTransaction().begin();
		entityManager.persist(loanProgramsOffered);
		entityManager.getTransaction().commit();
		isInserted=true;
	} catch (Exception e) {
		
		throw new LmsException(e.getMessage());
	}
		return isInserted;
	}

}
