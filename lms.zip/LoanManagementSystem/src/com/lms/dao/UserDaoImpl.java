package com.lms.dao;



import javax.persistence.EntityManager;

import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;


public class UserDaoImpl implements IUserDao {
private EntityManager entityManager;
public UserDaoImpl() {
	entityManager=JPAUtil.getEntityManager();
}
	@Override
	public Users addUser(Users users) throws LmsException {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(users);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
		
			throw new LmsException(e.getMessage());
		}
		return users;
	}
	public boolean authenticUser(String[] credential) throws LmsException {
		boolean isAuthentic=false;
		Users users;
		users=entityManager.find(Users.class, credential[0]);
		if(users!=null) {
			if(users.getLoginId().equals(credential[0]) && users.getPassword().equals(credential[1])) {
				isAuthentic=true;
			}
		}
		
		return isAuthentic;
	}
}
	
