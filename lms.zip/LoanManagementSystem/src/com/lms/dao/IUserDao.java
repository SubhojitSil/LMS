package com.lms.dao;

import com.lms.entity.Users;
import com.lms.exception.LmsException;

public interface IUserDao {
	public Users addUser(Users users) throws LmsException;

	public boolean authenticUser(String[] credential) throws LmsException;
}
