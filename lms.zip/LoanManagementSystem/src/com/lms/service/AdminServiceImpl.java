package com.lms.service;

import com.lms.dao.AdminDaoImpl;
import com.lms.dao.IAdminDao;
import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;

public class AdminServiceImpl implements IAdminService {
private IAdminDao adminDao;
public AdminServiceImpl() {
adminDao= new AdminDaoImpl();
}
	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException {
		boolean isInserted=false;
		isInserted=adminDao.isLoanProgramInserted(loanProgramsOffered);
		return isInserted;
	}

}
