package com.lms.service;

import com.lms.dao.IUserDao;
import com.lms.dao.UserDaoImpl;
import com.lms.entity.Users;
import com.lms.exception.LmsException;

public class UserServiceImpl implements IUserService {
 private IUserDao userDao;
 public UserServiceImpl() {
userDao = new UserDaoImpl(); 
}
	@Override
	public Users addUser(Users users) throws LmsException {
		userDao.addUser(users);
		return users;
	}
	@Override
	public boolean authenticUser(String[] credential) throws LmsException {
		boolean isAuthentic=userDao.authenticUser(credential);
		return isAuthentic;
	}

}
