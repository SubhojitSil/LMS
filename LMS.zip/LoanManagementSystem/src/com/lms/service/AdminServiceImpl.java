package com.lms.service;

import java.util.List;

import com.lms.dao.AdminDaoImpl;
import com.lms.dao.IAdminDao;
import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;

public class AdminServiceImpl implements IAdminService {
private IAdminDao adminDao;
public AdminServiceImpl() {
adminDao= new AdminDaoImpl();
}
	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException {
		boolean isInserted=false;
		isInserted=adminDao.isLoanProgramInserted(loanProgramsOffered);
		return isInserted;
	}
	@Override
	public boolean isDeleted(String programName) throws LmsException {
		boolean isDeleted=false;
		isDeleted=adminDao.isDeleted(programName);
		return isDeleted;
	}
	@Override
	public boolean isUpdated(String programName, int rate, int minAmount,
			int maxAmount, String idRequired) throws LmsException {
		boolean isUpdated= false;
		isUpdated=adminDao.isUpdated(programName, rate, minAmount, maxAmount, idRequired);
		return isUpdated;
	}
	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
	List<LoanProgramsOffered> viewAllllLoans=null;
	viewAllllLoans=adminDao.viewAll();
		return viewAllllLoans;
	}
	@Override
	public LoanProgramsOffered viewSprcific(String name) throws LmsException {
		LoanProgramsOffered specificLoan=adminDao.viewSprcific(name);
		
		return specificLoan;
	}
	@Override
	public boolean isRateUpdated(String programName, int rate)
			throws LmsException {
		boolean isRateUpdated=false;
		isRateUpdated=adminDao.isRateUpdated(programName, rate);
		return isRateUpdated;
	}

}
