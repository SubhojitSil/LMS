package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.IUserService;
import com.lms.service.UserServiceImpl;

public class Test {

	public static void main(String[] args) throws IOException, LmsException {
		IUserService userservice = new UserServiceImpl();
		IAdminService adminService = new AdminServiceImpl();
		Users users = new Users();
		LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// TO INSERT ADMIN N LAD

		
		/*  System.out.println("username"); users.setLoginId(br.readLine());
		  System.out.println("password"); users.setPassword(br.readLine());
		  System.out.println("role"); users.setRole(br.readLine()); Users
		  u=userservice.addUser(users); System.out.println(u);
		 */
		// TO CHECK VALID USER OR NOT

		/*
		 String[] credential=new String[2];
		 System.out.println("Enter username"); credential[0]=br.readLine();
		 System.out.println("enter Password"); credential[1]=br.readLine();
		  boolean isAuthentic=userservice.authenticUser(credential);
		  System.out.println(isAuthentic);*/
		 

		// TO INSERT LOAN PROGRAM OFFERED

		
		 /*System.out.println("enetr program name");
		  loanProgramOffered.setProgramName(br.readLine());
		  System.out.println("enter description");
		  loanProgramOffered.setDescription(br.readLine());
		  System.out.println("enter type");
		  loanProgramOffered.setType(br.readLine());
		  System.out.println("enter duration in years");
		  loanProgramOffered.setDurationInYears
		  (Integer.parseInt(br.readLine()));
		  System.out.println("enter min loan amount");
		  loanProgramOffered.setMinLoanAmount(Integer.parseInt(br.readLine()));
		  System.out.println("enter max loan amount");
		  loanProgramOffered.setMaxLoanAmount(Integer.parseInt(br.readLine()));
		  System.out.println("enter rate");
		  loanProgramOffered.setRateOfInterest
		  (Integer.parseInt(br.readLine()));
		  System.out.println("enter proofs");
		  loanProgramOffered.setProofsRequired(br.readLine());
		  
		 boolean
		  isInserted=adminService.isLoanProgramInserted(loanProgramOffered);
		  System.out.println(isInserted);
		 */

		  //TO DELETE
		 /*System.out.println("Enter program name");
		  boolean isDeleted=adminService.isDeleted(br.readLine());
		  System.out.println(isDeleted);*/
		
		
		//TO UPDATE
		/*System.out.println("Enter program name that needs to be updated");
		String programName=br.readLine();
		System.out.println("Enter the revised rate of interest");
		int rate=Integer.parseInt(br.readLine());
		System.out.println("Enter the min amount to be granted");
		int minAmount= Integer.parseInt(br.readLine());
		System.out.println("Enter the max Amount");
		int maxAmount= Integer.parseInt(br.readLine());
		System.out.println("enter the id required");
		String id=br.readLine();
		boolean isUpdated=adminService.isUpdated(programName, rate, minAmount, maxAmount, id);
		System.out.println(isUpdated);*/
		
		//VIEW ALL
		/*List<LoanProgramsOffered> viewAllLoans=null;
		viewAllLoans=adminService.viewAll();
		if(viewAllLoans==null){
			System.out.println("No loan Program exist for this bank");
		}else{
			for(LoanProgramsOffered loansPrograms:viewAllLoans){
				System.out.println(loansPrograms);
			}
		}*/
		
		//VIEW SPECIFIC 
		/* System.out.println("Enter loan program Name");
		 LoanProgramsOffered specificLoan=adminService.viewSprcific(br.readLine());
		 System.out.println(specificLoan);*/
		
		//UPDATE JUST RATE
		System.out.println("enter program name");
		String programName=br.readLine();
		System.out.println("enter rate");
		int rate=Integer.parseInt(br.readLine());
		boolean isRateUpdated=adminService.isRateUpdated(programName, rate);
		System.out.println(isRateUpdated);
		
		
	}

}
