package com.lms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lms.bean.*;
import com.lms.dao.AdminDAOImpl;
import com.lms.exception.LmsException;
/**
 * Servlet implementation class AdminRegistrationServlet
 */
@WebServlet("/AdminRegistrationServlet")
public class AdminRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName= request.getParameter("userName");
		String password= request.getParameter("password");
		String role="admin";
		
		Users users= new Users();
		users.setUsername(userName);
		users.setPassword(password);
		users.setRole("admin");

		boolean isInserted=false;
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//CALLING DAO
		AdminDAOImpl admin= new AdminDAOImpl();
		
		 try {
			isInserted=	admin.isInserted(users);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (LmsException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		if (isInserted)
		{
			request.setAttribute("ERRORMSG", "SUCCESSFULLY REGISTERED" );
			RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
			rd.forward(request, response);
			}else
		{
				request.setAttribute("ERRORMSG", "oops something went wrong try again later");
				RequestDispatcher rd=request.getRequestDispatcher("AdminRegistration.jsp");
				rd.forward(request, response);
		
			out.print("oops something went wrong try again later");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
