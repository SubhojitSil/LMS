package com.lms.dao;

public class QueryMapperAdmin {
public static final String INSERT_ADMIN= "INSERT INTO ADMIN (username, password, role) VALUES(?,?,admin)";
}
