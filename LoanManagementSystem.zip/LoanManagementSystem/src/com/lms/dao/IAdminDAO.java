package com.lms.dao;

import java.sql.SQLException;

import com.lms.bean.Users;
import com.lms.exception.LmsException;

public interface IAdminDAO {
 boolean isInserted(Users users) throws SQLException, LmsException;
}
