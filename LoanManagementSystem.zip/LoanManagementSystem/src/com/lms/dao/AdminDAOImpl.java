package com.lms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.lms.bean.Users;
import com.lms.exception.LmsException;
import com.lms.util.DBConnection;

;

public class AdminDAOImpl implements IAdminDAO {

	@Override
	public boolean isInserted(Users users) throws SQLException, LmsException {
		boolean isInserted = false;
		PreparedStatement preparedStatement = null;
		Connection con = null;
		try {
			Connection conn = DBConnection.getInstance().getConnection();

			preparedStatement = con
					.prepareStatement("insert into users(username, password, role)  values(?,?,?)");
			preparedStatement.setString(1, users.getUsername());
			preparedStatement.setString(2, users.getPassword());
			preparedStatement.setString(3, users.getRole());
			int i = preparedStatement.executeUpdate();

			if (i > 0)
				isInserted = true;
			// System.out.println("DATA INSERTED");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return isInserted;
	}

}
