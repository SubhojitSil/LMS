package com.lms.exception;

public class LmsException extends Exception {

	private static final long serialVersionUID = 1L;

	public LmsException() {
		super();
	}

	public LmsException(String message) {
		super(message);
	}	
}
